bash run_mode.sh 31@openml tabular mlp 3 avg

bash run_mode.sh 53@openml tabular mlp 3 avg

bash run_mode.sh 3917@openml tabular mlp 3 avg


bash run_mode.sh cola@huggingface_datasets tabular bert 3 avg
bash run_mode.sh cola@huggingface_datasets tabular bert 3 opt

bash run_mode.sh sst2@huggingface_datasets tabular bert 3 avg
bash run_mode.sh sst2@huggingface_datasets tabular bert 3 opt