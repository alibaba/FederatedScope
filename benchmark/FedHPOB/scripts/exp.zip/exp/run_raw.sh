#
nohup bash run_mode.sh cora raw gcn 0 avg &
nohup bash run_mode.sh cora raw gcn 0 opt &

#
nohup bash run_mode.sh citeseer raw gcn 1 avg &
nohup bash run_mode.sh citeseer raw gcn 1 opt &

#
nohup bash run_mode.sh pubmed raw gcn 2 avg &
nohup bash run_mode.sh pubmed raw gcn 2 opt &

#
nohup bash run_mode.sh 31@openml raw lr 3 avg &
nohup bash run_mode.sh 31@openml raw lr 3 opt &

nohup bash run_mode.sh 31@openml raw mlp 0 avg &
nohup bash run_mode.sh 31@openml raw mlp 0 opt &

#
nohup bash run_mode.sh 53@openml raw lr 1 avg &
nohup bash run_mode.sh 53@openml raw lr 1 opt &

nohup bash run_mode.sh 53@openml raw mlp 2 avg &
nohup bash run_mode.sh 53@openml raw mlp 2 opt &

#
nohup bash run_mode.sh 3917@openml raw lr 3 avg &
nohup bash run_mode.sh 3917@openml raw lr 3 opt &

nohup bash run_mode.sh 3917@openml raw mlp 0 avg &
nohup bash run_mode.sh 3917@openml raw mlp 0 opt &

#
nohup bash run_mode.sh 9952@openml raw lr 1 avg &
nohup bash run_mode.sh 9952@openml raw lr 1 opt &

nohup bash run_mode.sh 9952@openml raw mlp 2 avg &
nohup bash run_mode.sh 9952@openml raw mlp 2 opt &

#
nohup bash run_mode.sh 10101@openml raw lr 3 avg &
nohup bash run_mode.sh 10101@openml raw lr 3 opt &

nohup bash run_mode.sh 10101@openml raw mlp 0 avg &
nohup bash run_mode.sh 10101@openml raw mlp 0 opt &

#
nohup bash run_mode.sh 146818@openml raw lr 1 avg &
nohup bash run_mode.sh 146818@openml raw lr 1 opt &

nohup bash run_mode.sh 146818@openml raw mlp 2 avg &
nohup bash run_mode.sh 146818@openml raw mlp 2 opt &

#
nohup bash run_mode.sh 146821@openml raw lr 3 avg &
nohup bash run_mode.sh 146821@openml raw lr 3 opt &

nohup bash run_mode.sh 146821@openml raw mlp 0 avg &
nohup bash run_mode.sh 146821@openml raw mlp 0 opt &

#
nohup bash run_mode.sh 146822@openml raw lr 2 avg &
nohup bash run_mode.sh 146822@openml raw lr 2 opt &

nohup bash run_mode.sh 146822@openml raw mlp 3 avg &
nohup bash run_mode.sh 146822@openml raw mlp 3 opt &