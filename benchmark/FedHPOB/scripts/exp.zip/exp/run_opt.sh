bash run_mode.sh 3917@openml tabular lr 3 opt

bash run_mode.sh 10101@openml tabular lr 3 opt

bash run_mode.sh 146818@openml tabular lr 1 opt

bash run_mode.sh 146821@openml tabular lr 3 opt

bash run_mode.sh 146822@openml tabular lr 2 opt